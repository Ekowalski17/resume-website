# Import the datetime class from the datetime
# module so that it can be used in this program.
import csv
from datetime import datetime

#Define index
PRODUCT_NUM_INDEX = 0

def main():
    #Print Inkom Emporium, the store name, 
    #on the top of the receipt
    STORE_NAME = "INKOM EMPORIUM"
    print(STORE_NAME)
    print()
    
    #Call and stores the read_products function
    #Next, stores the products dict into a variable products
    products=read_products()
        
    #Print the products dictionary and below: 
    #This will print the list of ordered items
    #This will also add and print the number of ordered items
    
    
    #Print the process_request function
    quantity, subtotal = process_request(products)
    
    #Add and printe the total subtotal due
    #Compute and print the sales tax rate
    #Compute and print the total amount due
    
    #calculating sales tax 
    TAX_RATE = 0.06
    sales_tax = subtotal *TAX_RATE
    total = subtotal+sales_tax
    print(f"Number of items: {quantity:.0f}")
    print(f"Subtotal: {subtotal:.2f}")
    print(f"Sales Tax: {sales_tax:.2f}")  
    print(f"Total: {total:.2f}")
    print()
    
    
    
    #Print a thank you message
    print(f"Thank you for shopping at {STORE_NAME}")
    
    # Call the now() method to get the current
    # date and time as a datetime object from
    # the computer's operating system.
    current_date_and_time = datetime.now()

    # Print the current day of the week and the current time.
    print(f"{current_date_and_time:%A %I:%M %p}")
    current_date_and_time = datetime.now()
    print(f"{current_date_and_time:%a %b %d %H:%M:%S %Y}")
    
#create a read_products():
def read_products(): 
    products = {}
    try: 
        #opens the products.csv file for reading
        with open ("products.csv", mode="rt") as products_file:
            
            # Use the standard csv module to get
            # a reader object for the CSV file.
            reader = csv.reader(products_file)
            next(reader)
    
            #Define more index
            NAME_INDEX = 1
            PRICE_INDEX = 2
    
        #Go through and process the rows one at a time
            for row in reader:
                product_num = row[PRODUCT_NUM_INDEX]
                product_name = row[NAME_INDEX]
                product_price = row[PRICE_INDEX]
        
                #populate a dictionary with the information of the products.csv file
                products[product_num] = [product_name, product_price]
    
    #Included a try block and except blocks to handle filenot found errpr,
    #permission error, key error
    except FileNotFoundError as not_found_err:
        print(not_found_err)
     
    except PermissionError as perm_err:
        print(perm_err)
    
    except Exception as error:
        print(error)
    
    #return the dictionary    
    return products
 
#create process_request(products):   
def process_request(products):
    try:
        #open the request.csv file to read
        file_name="request.csv"
        with open("request.csv", mode="rt") as requests_file:
        
            # Use the standard csv module to get
            # a reader object for the CSV file 
            reader = csv.reader(requests_file)
            next(reader)
            
            #Define more index
            QUANTITY_INDEX = 1
            NAME_INDEX = 0
            PRICE_INDEX = 1
            
            #Go through the same and process the rows one at a time   
            num_items = 0
            subtotal = 0
            for row in reader:
                product_num = row [PRODUCT_NUM_INDEX]
                product_quantity = int(row[QUANTITY_INDEX])
                num_items += product_quantity  
                #Use the requested product number to find the matching item
                #in the product dictionary
                product = products[product_num]
            
                #get product info
                product_name = product[NAME_INDEX]
                product_price = float(product[PRICE_INDEX])
                subtotal += product_price * product_quantity
                
                #This will display the products that is being added in the receipt
                print(f"{product_name}: {product_quantity} @ {product_price}")
            
            print()
    
    #my excepetions      
    except FileNotFoundError as not_found_err:
        print("Error: missing file")
        print(not_found_err)
     
    except PermissionError as perm_err:
        print(perm_err) 
               
    except KeyError as key_err:
        print(f"Unknown product Id in the {file_name} file ")
            
        print(type(key_err).__name__, key_err) 
    
    return num_items, subtotal

#Call main to start this program
if __name__ == "__main__":
    main()
        
        