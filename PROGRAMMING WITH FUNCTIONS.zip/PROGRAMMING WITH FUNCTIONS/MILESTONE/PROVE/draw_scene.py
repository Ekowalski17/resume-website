# Import the functions from the Draw 2-D library
# so that they can be used in this program.
from random import random
from textwrap import fill
from turtle import width
from draw2d import \
    start_drawing, draw_line, draw_oval, draw_arc, \
    draw_rectangle, draw_polygon, draw_text, finish_drawing


def main():
    # Width and height of the scene in pixels
    scene_width = 800
    scene_height = 500

    # Call the start_drawing function in the draw2d.py library
    # which will open a window and create a canvas.
    canvas = start_drawing("Scene", scene_width, scene_height)

    # Call your drawing functions such
    # as draw_sky and draw_ground here.
    draw_sky(canvas, scene_width, scene_height)
    draw_clouds(canvas, scene_width, scene_height)
    draw_sand(canvas, scene_width, scene_height)
    draw_sun(canvas, scene_width, scene_height)
    draw_coconut(canvas, scene_width, scene_height)

    # Call the finish_drawing function
    # in the draw2d.py library.
    finish_drawing(canvas)


# Define your functions such as
# draw_sky and draw_ground here.

#Draw the sky
def draw_sky(canvas, scene_width, scene_height):
    """Draw the sky and all the objects in the sky."""
    draw_rectangle(canvas, 0,0 ,
        scene_width, scene_height, width=0, fill="lightBlue1")

#Draw the clouds
def draw_clouds(canvas, scene_width, scene_height):
    draw_oval (canvas, 50, 200, 300, 250, outline ="ghostWhite", fill =
    "ghostWhite")
    draw_oval (canvas, 70, 200, 250, 300, outline ="ghostWhite", fill =
    "ghostWhite")
    draw_oval (canvas, 500, 300, 790, 350, outline ="ghostWhite", fill =
    "ghostWhite")
    draw_oval (canvas, 550, 320, 740, 400, outline ="ghostWhite", fill =
    "ghostWhite")
 

#Draw the ground
def draw_sand(canvas, scene_width, scene_height):
    draw_rectangle (canvas, 0, 0,
    scene_width, scene_height / 5, width = 0, fill = "deepSkyBlue")
    

#Draw the sun
def draw_sun(canvas, scene_width, scene_height):
    draw_arc(canvas, 300, 0, 500, 200, start=0, extent=180, width=0, outline="Khaki1", fill="Khaki1")                                                                         
    #Draw shadow of the sun
    draw_line(canvas, 300, 90, 500, 90, width=5,fill="gold1")
    draw_line(canvas, 310, 80, 490, 80, width=5,fill="goldenrod1")
    draw_line(canvas, 320, 70, 480, 70, width=5,fill="darkGoldenrod1")

#Draw coconut
def draw_coconut(canvas, scene_width, scene_height):
    draw_arc(canvas, 10, 30, 150, 260, start=0, extent=-180, width=0, outline="tan4", fill="tan4" )
    draw_line(canvas, 10, 148, 150, 148, width=5, fill="ghostWhite") 
    draw_oval(canvas, 70, 40, 90, 69, outline ="ghostWhite", fill =
    "ghostWhite")
    draw_line(canvas, 100, 150, 150, 210, width=5, fill="black")
    draw_line(canvas, 150, 210, 190, 210, width=5, fill="black")


  

# Call the main function so that
# this program will start executing.
main()