
# CSE 111 Functions
# Scott LeFoll
# 04/18/22
#
# Problem Statement
#
# The size of a car tire in the United States is represented with three numbers like this: 205/60R15.
# The first number is the width of the tire in millimeters. The second number is the aspect ratio.
# The third number is the diameter in inches of the wheel that the tire fits. The volume of space
# inside a tire can be approximated with this formula:
# v = (π * (w ** 2a) * (w*a + 2,540*d)) / 10,000,000,000
# v is the volume in liters,
# π is the constant PI, which is the ratio of the circumference of a circle dividedby its diameter
# (use math.pi),
# w is the width of the tire in millimeters,
# 'a' is the aspect ratio of the tire, and
# d is the diameter of the wheel in inches.
#
import math
# import re
from datetime import date
def volume_engine(w, a, d):
    return (math.pi * (w ** 2) * a * (w * a + 2540 * d)) / (1 * 10 ** 10)
def format_phone(p):
    p_lst = [char for char in p]
    p_lst.insert(0, '(')
    p_lst.insert(4, ')')
    p_lst.insert(8, '-')
    # return re.sub(r'(?<!\S)(\d{3})-', r'(\1) ', p)
    return "".join(p_lst)
quantity = 0
W = 0
D = 0
A = 0
print()
while True:
    mode = input("Please enter the input mode ('1' = '185/50R14' ; '2' = discrete entries): ")
    if mode not in ('1', '2'):
        print("Please enter a valid input mode: '1' or '2'")
    else:
        break
match mode:
    case "1":
        while True:
            size = input("Please enter the size of the tire (ie. '185/50R14'): ").upper()
            if '/' not in size or 'R' not in size:
                print("Please enter a tire size in this format: '185/50R14'.")
            else:
                break
        W = int((size[0:size.find('/')]))
        A = int((size[size.find('/') + 1:size.find('R')]))
        D = int((size[size.find('R') + 1:len(size)]))
    case "2":
        while True:
            try:
                W = int(input("Please enter the width of the tire in millimeters (ie. '205'): "))
            except ValueError:
                print("Please enter a valid width in whole numbers.")
                continue
            else:
                print()
                break
        while True:
            try:
                A = int(input("Please enter the aspect ratio of the tire (ie. '60'): "))
            except ValueError:
                print("Please enter a valid aspect in whole numbers.")
                continue
            else:
                print()
                break
        while True:
            try:
                D = int(input("Please enter the diameter of the tire in inches (ie.'15'): "))
            except ValueError:
                print("Please enter a valid diameter.")
                continue
            else:
                print()
                break
V = volume_engine(W, A, D)
print(f"The approximate volume of a tire of size {W}/{A}R{D} is {V:.2f} liters.")
# Assignment
# The previous lesson's prove milestone required you to write a program named tire_volume.py that computes the
# approximate volume of air inside a tire. Add code near the end of that program that does the following:
#
# Gets the current date from the computer's operating system.
# Opens a text file named volumes.txt for appending.
# Appends to the end of the volumes.txt file one line of text that contains the following five values:
# current date
# width of the tire
# aspect ratio of the tire
# diameter of the wheel
# volume of the tire
# Find tire prices for four or more tire sizes online. Add a set of if ... elif ... else statements in your program that use
# the tire width, tire aspect ratio, and wheel diameter that the user enters to find a price and then print the price.
# After your program prints the tire volume to the terminal window, your program should ask the user if she wants
# to buy tires with the dimensions that she entered. If the user answers "yes", your program should ask for her phone
# number and store her phone number in the volumes.txt file.
date = date.today()
while True:
    try:
        quantity = int(input(f"How many tires of size {W}/{A}R{D} would you like tobuy? ('0', '1', '2', '3', '4'): "))
    except ValueError:
        print("Please enter a whole number.")
        continue
    else:
        break
if quantity > 0:
    while True:
        name = input("Please enter your full name (ie. 'John Smith'): ").title()
        if name == "" or name.find(' ') == -1:
            print("Please enter a valid name.")
        else:
            break
    while True:
        phone = input("Please enter your phone #, including area code ('802-275-2698'): ")
        digit_filter = filter(str.isdigit, phone)
        phone = "".join(digit_filter)
        if len(phone) != 10 or int(phone[0:1]) < 2:
            print("Please enter a valid phone #.")
        else:
            phone_us = format_phone(phone)
            break
    with open('volumes.txt', 'w') as f:
        f.writelines(f"Name: {name}\n")
        f.writelines(f"Phone #: {phone_us}\n\n")
        f.writelines(f"Date       Width  Aspect  Diameter   Volume     Quantity\n")
        f.writelines(f"{date}   {W}    {A}      {D}        {V:.2f}      {quantity}\n\n")
else:
    with open('volumes.txt', 'w') as f:
        f.writelines(f"Date       Width  Aspect  Diameter   Volume\n")
        f.writelines(f"{date}   {W}    {A}      {D}        {V:.2f}\n\n")