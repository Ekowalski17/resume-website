from amazon import read_sum
import pandas as pd
from os import path
from tempfile import mktemp
from pytest import approx
import pytest

def test_sum():
    test_df = pd.read_csv("order_history.csv")
    assert test_df
pytest.main(["-v", "--tb=line", "-rN", __file__])